﻿namespace Individual_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.AddEventButton = new System.Windows.Forms.Button();
            this.DeleteEventButton = new System.Windows.Forms.Button();
            this.ViewEventButton = new System.Windows.Forms.Button();
            this.EditEventButton = new System.Windows.Forms.Button();
            this.ViewMonthlyButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.updateButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.CancelButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.DescriptionTextBox = new System.Windows.Forms.TextBox();
            this.AttendeesTextBox = new System.Windows.Forms.TextBox();
            this.LocationTextBox = new System.Windows.Forms.TextBox();
            this.ReminderTimeTextBox = new System.Windows.Forms.TextBox();
            this.EndingTimeTextBox = new System.Windows.Forms.TextBox();
            this.StartingTimeTextBox = new System.Windows.Forms.TextBox();
            this.TitleTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(48, 43);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(24, 21, 24, 21);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 0;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.MonthCalendar1_DateChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 31;
            this.listBox1.Location = new System.Drawing.Point(685, 141);
            this.listBox1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(305, 748);
            this.listBox1.TabIndex = 1;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.ListBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(688, 79);
            this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "Events on 02/03/2020";
            // 
            // AddEventButton
            // 
            this.AddEventButton.Location = new System.Drawing.Point(48, 458);
            this.AddEventButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.AddEventButton.Name = "AddEventButton";
            this.AddEventButton.Size = new System.Drawing.Size(269, 55);
            this.AddEventButton.TabIndex = 3;
            this.AddEventButton.Text = "Add Event";
            this.AddEventButton.UseVisualStyleBackColor = true;
            this.AddEventButton.Click += new System.EventHandler(this.Button1_Click);
            // 
            // DeleteEventButton
            // 
            this.DeleteEventButton.Location = new System.Drawing.Point(48, 527);
            this.DeleteEventButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.DeleteEventButton.Name = "DeleteEventButton";
            this.DeleteEventButton.Size = new System.Drawing.Size(269, 55);
            this.DeleteEventButton.TabIndex = 4;
            this.DeleteEventButton.Text = "Delete Event";
            this.DeleteEventButton.UseVisualStyleBackColor = true;
            this.DeleteEventButton.Click += new System.EventHandler(this.Button2_Click);
            // 
            // ViewEventButton
            // 
            this.ViewEventButton.Location = new System.Drawing.Point(48, 665);
            this.ViewEventButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.ViewEventButton.Name = "ViewEventButton";
            this.ViewEventButton.Size = new System.Drawing.Size(269, 55);
            this.ViewEventButton.TabIndex = 5;
            this.ViewEventButton.Text = "View Event";
            this.ViewEventButton.UseVisualStyleBackColor = true;
            this.ViewEventButton.Click += new System.EventHandler(this.ViewEventButton_Click);
            // 
            // EditEventButton
            // 
            this.EditEventButton.Location = new System.Drawing.Point(48, 596);
            this.EditEventButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.EditEventButton.Name = "EditEventButton";
            this.EditEventButton.Size = new System.Drawing.Size(269, 55);
            this.EditEventButton.TabIndex = 6;
            this.EditEventButton.Text = "Edit Event";
            this.EditEventButton.UseVisualStyleBackColor = true;
            this.EditEventButton.Click += new System.EventHandler(this.EditEventButton_Click);
            // 
            // ViewMonthlyButton
            // 
            this.ViewMonthlyButton.Location = new System.Drawing.Point(48, 734);
            this.ViewMonthlyButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.ViewMonthlyButton.Name = "ViewMonthlyButton";
            this.ViewMonthlyButton.Size = new System.Drawing.Size(269, 55);
            this.ViewMonthlyButton.TabIndex = 7;
            this.ViewMonthlyButton.Text = "View Monthly Events";
            this.ViewMonthlyButton.UseVisualStyleBackColor = true;
            this.ViewMonthlyButton.Click += new System.EventHandler(this.ViewMonthlyButton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.updateButton);
            this.panel1.Controls.Add(this.deleteButton);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.CancelButton);
            this.panel1.Controls.Add(this.SaveButton);
            this.panel1.Controls.Add(this.DescriptionTextBox);
            this.panel1.Controls.Add(this.AttendeesTextBox);
            this.panel1.Controls.Add(this.LocationTextBox);
            this.panel1.Controls.Add(this.ReminderTimeTextBox);
            this.panel1.Controls.Add(this.EndingTimeTextBox);
            this.panel1.Controls.Add(this.StartingTimeTextBox);
            this.panel1.Controls.Add(this.TitleTextBox);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(1043, 43);
            this.panel1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(907, 985);
            this.panel1.TabIndex = 8;
            this.panel1.Visible = false;
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(51, 861);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(322, 55);
            this.updateButton.TabIndex = 19;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Visible = false;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(51, 858);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(320, 58);
            this.deleteButton.TabIndex = 18;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Visible = false;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(267, 207);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(559, 39);
            this.comboBox2.TabIndex = 17;
            this.comboBox2.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(267, 143);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(559, 39);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.Visible = false;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(512, 858);
            this.CancelButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(320, 55);
            this.CancelButton.TabIndex = 15;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(51, 858);
            this.SaveButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(320, 55);
            this.SaveButton.TabIndex = 14;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.Button6_Click);
            // 
            // DescriptionTextBox
            // 
            this.DescriptionTextBox.Location = new System.Drawing.Point(51, 498);
            this.DescriptionTextBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.DescriptionTextBox.Multiline = true;
            this.DescriptionTextBox.Name = "DescriptionTextBox";
            this.DescriptionTextBox.Size = new System.Drawing.Size(775, 340);
            this.DescriptionTextBox.TabIndex = 13;
            // 
            // AttendeesTextBox
            // 
            this.AttendeesTextBox.Location = new System.Drawing.Point(267, 391);
            this.AttendeesTextBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.AttendeesTextBox.Name = "AttendeesTextBox";
            this.AttendeesTextBox.Size = new System.Drawing.Size(559, 38);
            this.AttendeesTextBox.TabIndex = 12;
            // 
            // LocationTextBox
            // 
            this.LocationTextBox.Location = new System.Drawing.Point(267, 329);
            this.LocationTextBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.LocationTextBox.Name = "LocationTextBox";
            this.LocationTextBox.Size = new System.Drawing.Size(559, 38);
            this.LocationTextBox.TabIndex = 11;
            // 
            // ReminderTimeTextBox
            // 
            this.ReminderTimeTextBox.Location = new System.Drawing.Point(267, 267);
            this.ReminderTimeTextBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.ReminderTimeTextBox.Name = "ReminderTimeTextBox";
            this.ReminderTimeTextBox.Size = new System.Drawing.Size(559, 38);
            this.ReminderTimeTextBox.TabIndex = 10;
            // 
            // EndingTimeTextBox
            // 
            this.EndingTimeTextBox.Location = new System.Drawing.Point(267, 207);
            this.EndingTimeTextBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.EndingTimeTextBox.Name = "EndingTimeTextBox";
            this.EndingTimeTextBox.Size = new System.Drawing.Size(559, 38);
            this.EndingTimeTextBox.TabIndex = 9;
            // 
            // StartingTimeTextBox
            // 
            this.StartingTimeTextBox.Location = new System.Drawing.Point(267, 143);
            this.StartingTimeTextBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.StartingTimeTextBox.Name = "StartingTimeTextBox";
            this.StartingTimeTextBox.Size = new System.Drawing.Size(559, 38);
            this.StartingTimeTextBox.TabIndex = 8;
            // 
            // TitleTextBox
            // 
            this.TitleTextBox.Location = new System.Drawing.Point(267, 81);
            this.TitleTextBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.TitleTextBox.Name = "TitleTextBox";
            this.TitleTextBox.Size = new System.Drawing.Size(559, 38);
            this.TitleTextBox.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(43, 284);
            this.label8.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 32);
            this.label8.TabIndex = 6;
            this.label8.Text = "Reminder Time";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 460);
            this.label7.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 32);
            this.label7.TabIndex = 5;
            this.label7.Text = "Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 408);
            this.label6.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 32);
            this.label6.TabIndex = 4;
            this.label6.Text = "Attendees";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 346);
            this.label5.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 32);
            this.label5.TabIndex = 3;
            this.label5.Text = "Location";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 224);
            this.label4.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 32);
            this.label4.TabIndex = 2;
            this.label4.Text = "Ending Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 160);
            this.label3.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 32);
            this.label3.TabIndex = 1;
            this.label3.Text = "Starting Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "Title";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2091, 1114);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ViewMonthlyButton);
            this.Controls.Add(this.EditEventButton);
            this.Controls.Add(this.ViewEventButton);
            this.Controls.Add(this.DeleteEventButton);
            this.Controls.Add(this.AddEventButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.monthCalendar1);
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "Form1";
            this.Text = "Personal Calendar";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AddEventButton;
        private System.Windows.Forms.Button DeleteEventButton;
        private System.Windows.Forms.Button ViewEventButton;
        private System.Windows.Forms.Button EditEventButton;
        private System.Windows.Forms.Button ViewMonthlyButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox DescriptionTextBox;
        private System.Windows.Forms.TextBox AttendeesTextBox;
        private System.Windows.Forms.TextBox LocationTextBox;
        private System.Windows.Forms.TextBox ReminderTimeTextBox;
        private System.Windows.Forms.TextBox EndingTimeTextBox;
        private System.Windows.Forms.TextBox StartingTimeTextBox;
        private System.Windows.Forms.TextBox TitleTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button updateButton;
    }
}

