﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Individual_Project
{
    public partial class Form1 : Form
    {
        ArrayList eList;
        Event selectedEvent;
        public Form1()
        {
            InitializeComponent();
            DateTime thisDay = DateTime.Today;
            String dateString = thisDay.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            
            Console.Out.WriteLine("dateString: " + dateString);
            label1.Text = "Events on " + dateString;
            eList = Event.getEventList(dateString);
            SaveButton.Visible = false;
            CancelButton.Visible = false;
            
            listBox1.Items.Clear();
            for(int i = 0; i<eList.Count; i++)
            {
                Event currentEvent = (Event)eList[i];
                String aString = currentEvent.getStartTime() + " " + currentEvent.getTitle();
                listBox1.Items.Add(aString);
            }
            initializeTimeSelection();
            

        }
        private void initializeTimeSelection()
        {
            //comboBox1.Visible = true;
            comboBox1.Items.Add("00:00");
            comboBox1.Items.Add("00:30");
            comboBox1.Items.Add("01:00");
            comboBox1.Items.Add("01:30");
            comboBox1.Items.Add("02:00");
            comboBox1.Items.Add("02:30");
            comboBox1.Items.Add("03:00");
            comboBox1.Items.Add("03:30");
            comboBox1.Items.Add("04:00");
            comboBox1.Items.Add("04:30");
            comboBox1.Items.Add("05:00");
            comboBox1.Items.Add("05:30");
            comboBox1.Items.Add("06:00");
            comboBox1.Items.Add("06:30");
            comboBox1.Items.Add("07:00");
            comboBox1.Items.Add("07:30");
            comboBox1.Items.Add("08:00");
            comboBox1.Items.Add("08:30");
            comboBox1.Items.Add("09:00");
            comboBox1.Items.Add("09:30");
            comboBox1.Items.Add("10:00");
            comboBox1.Items.Add("10:30");
            comboBox1.Items.Add("11:00");
            comboBox1.Items.Add("11:30");
            comboBox1.Items.Add("12:00");
            comboBox1.Items.Add("12:30");
            comboBox1.Items.Add("13:00");
            comboBox1.Items.Add("13:30");
            comboBox1.Items.Add("14:00");
            comboBox1.Items.Add("14:30");
            comboBox1.Items.Add("15:00");
            comboBox1.Items.Add("15:30");
            comboBox1.Items.Add("16:00");
            comboBox1.Items.Add("16:30");
            comboBox1.Items.Add("17:00");
            comboBox1.Items.Add("17:30");
            comboBox1.Items.Add("18:00");
            comboBox1.Items.Add("18:30");
            comboBox1.Items.Add("19:00");
            comboBox1.Items.Add("19:30");
            comboBox1.Items.Add("20:00");
            comboBox1.Items.Add("20:30");
            comboBox1.Items.Add("21:00");
            comboBox1.Items.Add("21:30");
            comboBox1.Items.Add("22:00");
            comboBox1.Items.Add("22:30");
            comboBox1.Items.Add("23:00");
            comboBox1.Items.Add("23:30");

            comboBox2.Items.Add("00:00");
            comboBox2.Items.Add("00:30");
            comboBox2.Items.Add("01:00");
            comboBox2.Items.Add("01:30");
            comboBox2.Items.Add("02:00");
            comboBox2.Items.Add("02:30");
            comboBox2.Items.Add("03:00");
            comboBox2.Items.Add("03:30");
            comboBox2.Items.Add("04:00");
            comboBox2.Items.Add("04:30");
            comboBox2.Items.Add("05:00");
            comboBox2.Items.Add("05:30");
            comboBox2.Items.Add("06:00");
            comboBox2.Items.Add("06:30");
            comboBox2.Items.Add("07:00");
            comboBox2.Items.Add("07:30");
            comboBox2.Items.Add("08:00");
            comboBox2.Items.Add("08:30");
            comboBox2.Items.Add("09:00");
            comboBox2.Items.Add("09:30");
            comboBox2.Items.Add("10:00");
            comboBox2.Items.Add("10:30");
            comboBox2.Items.Add("11:00");
            comboBox2.Items.Add("11:30");
            comboBox2.Items.Add("12:00");
            comboBox2.Items.Add("12:30");
            comboBox2.Items.Add("13:00");
            comboBox2.Items.Add("13:30");
            comboBox2.Items.Add("14:00");
            comboBox2.Items.Add("14:30");
            comboBox2.Items.Add("15:00");
            comboBox2.Items.Add("15:30");
            comboBox2.Items.Add("16:00");
            comboBox2.Items.Add("16:30");
            comboBox2.Items.Add("17:00");
            comboBox2.Items.Add("17:30");
            comboBox2.Items.Add("18:00");
            comboBox2.Items.Add("18:30");
            comboBox2.Items.Add("19:00");
            comboBox2.Items.Add("19:30");
            comboBox2.Items.Add("20:00");
            comboBox2.Items.Add("20:30");
            comboBox2.Items.Add("21:00");
            comboBox2.Items.Add("21:30");
            comboBox2.Items.Add("22:00");
            comboBox2.Items.Add("22:30");
            comboBox2.Items.Add("23:00");
            comboBox2.Items.Add("23:30");

        }

        private void MonthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            String thisDate = monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd");
            
            label1.Text = "Events on " + thisDate;
            eList = Event.getEventList(thisDate);
            //SaveButton.Visible = false;
            //CancelButton.Visible = false;
            listBox1.Items.Clear();
            for (int i = 0; i < eList.Count; i++)
            {
                Event currentEvent = (Event)eList[i];
                String aString = currentEvent.getStartTime() + " " + currentEvent.getTitle();
                listBox1.Items.Add(aString);
            }
            if (eList.Count == 0)
                selectedEvent = null;
            else
                selectedEvent = (Event) eList[0];
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            DeleteEventButton.BackColor = Color.Red;
            SaveButton.Visible = false;
            deleteButton.Visible = true;
            CancelButton.Visible = true;
            DeleteEventButton.Enabled = false;
            EditEventButton.Enabled = false;
            ViewEventButton.Enabled = false;
            ViewMonthlyButton.Enabled = false;
            CancelButton.Visible = true;
            AddEventButton.Enabled = false;
            EditEventButton.Enabled = false;
            ViewEventButton.Enabled = false;
            ViewMonthlyButton.Enabled = false;

            panel1.Visible = true;
            StartingTimeTextBox.Text = "";
            StartingTimeTextBox.Visible = false;
            comboBox1.Visible = true;
            TitleTextBox.Text = "";
            EndingTimeTextBox.Text = "";
            EndingTimeTextBox.Visible = false;
            comboBox2.Visible = true;
            ReminderTimeTextBox.Text = "";
            LocationTextBox.Text = "";
            AttendeesTextBox.Text = "";
            DescriptionTextBox.Text = "";

            
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            AddEventButton.BackColor = Color.Red;
            panel1.Visible = true;
            StartingTimeTextBox.Text = "";
            StartingTimeTextBox.Visible = false;
            comboBox1.Visible = true;
            TitleTextBox.Text = "";
            EndingTimeTextBox.Text = "";
            EndingTimeTextBox.Visible = false;
            comboBox2.Visible = true;
            ReminderTimeTextBox.Text = "";
            LocationTextBox.Text = "";
            AttendeesTextBox.Text = "";
            DescriptionTextBox.Text = "";

            SaveButton.Visible = true;
            CancelButton.Visible = true;
            DeleteEventButton.Enabled = false;
            EditEventButton.Enabled = false;
            ViewEventButton.Enabled = false;
            ViewMonthlyButton.Enabled = false;
            //string messageBoxText = "Please select a date from the monthly calendar to add a new event.";
            //string caption = "Add New Event";
            //MessageBoxButtons button = MessageBoxButtons.OK;
            //MessageBoxIcon icon = MessageBoxIcon.Warning;
            //MessageBox.Show(messageBoxText, caption, button);
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            //add an event if possible

            if(comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
            {
                String message = "The new event is missing information.";
                String caption = "Error Detected with Missing information";
                MessageBoxButtons button = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, button);
            }
            else if(comboBox1.SelectedItem.ToString().CompareTo(comboBox2.SelectedItem.ToString())>=0)
            {
                String message = "The new event has incorrect times.";
                String caption = "Error Detected with times.";
                MessageBoxButtons button = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, button);
            }
            else
            {
                Event newEvent = new Event();
                newEvent.updateEventValue(TitleTextBox.Text, comboBox1.SelectedItem.ToString(), comboBox2.SelectedItem.ToString(), ReminderTimeTextBox.Text, LocationTextBox.Text, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"), DescriptionTextBox.Text);
                bool noConflict = newEvent.checkConflict(eList);
                Console.WriteLine("Conflict = " + noConflict);
                if (noConflict == false)
                {
                    String message = "The new event has time conflicts with some existing event.";
                    String caption = "Error Detected in Time Specification";
                    MessageBoxButtons button = MessageBoxButtons.OK;
                    MessageBox.Show(message, caption, button);

                }
                else
                {
                    String message = "The new event has been saved to the database sucessfully";
                    String caption = "New Event Has Been Saved";
                    MessageBoxButtons button = MessageBoxButtons.OK;
                    MessageBox.Show(message, caption, button);

                    //save to database
                    newEvent.insertEvent();
                    emptyEventForm();
                    panel1.Visible = false;
                    AddEventButton.Enabled = true;
                    DeleteEventButton.Enabled = true;
                    AddEventButton.BackColor = SystemColors.ButtonFace;
                    EditEventButton.Enabled = true;
                    ViewEventButton.Enabled = true;
                    ViewMonthlyButton.Enabled = true;
                }

               
            }





        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
                listBox1.SelectedIndex = 0;
         
            Event currentEvent = (Event)eList[listBox1.SelectedIndex];
            selectedEvent = currentEvent;
            TitleTextBox.Text = currentEvent.getTitle();
            StartingTimeTextBox.Text = currentEvent.getStartTime();
            comboBox1.Visible = false;
            StartingTimeTextBox.Visible = true;
            EndingTimeTextBox.Text = currentEvent.getEndTime();
            comboBox2.Visible = false;
            EndingTimeTextBox.Visible = true;
            DescriptionTextBox.Text = currentEvent.getDescription();
            ReminderTimeTextBox.Text = currentEvent.getReminder();
            LocationTextBox.Text = currentEvent.getLocation();

            
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void emptyEventForm()
        {
            //clears areas to enter data

            StartingTimeTextBox.Text = "";
            
            TitleTextBox.Text = "";
            EndingTimeTextBox.Text = "";
            ReminderTimeTextBox.Text = "";
            LocationTextBox.Text = "";
            AttendeesTextBox.Text = "";
            DescriptionTextBox.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
        }
        private void CancelButton_Click(object sender, EventArgs e)
        {
            //enables main buttons and hides the rest
            AddEventButton.Enabled = true;
            DeleteEventButton.Enabled = true;
            EditEventButton.Enabled = true;
            ViewEventButton.Enabled = true;
            ViewMonthlyButton.Enabled = true;
            AddEventButton.BackColor = DefaultBackColor;
            DeleteEventButton.BackColor = DefaultBackColor;
            EditEventButton.BackColor = DefaultBackColor;
            ViewEventButton.BackColor = DefaultBackColor;
            ViewMonthlyButton.BackColor = DefaultBackColor;
            SaveButton.Visible = false;
            CancelButton.Visible = false;
            deleteButton.Visible = false;
            updateButton.Visible = false;
            comboBox1.Visible = false;
            panel1.Visible = false;
            StartingTimeTextBox.Visible = true;
          
            emptyEventForm();
            if(eList.Count != 0)
            {
                ListBox1_SelectedIndexChanged(sender, e);
            }
           
           
        }

        private void EditEventButton_Click(object sender, EventArgs e)
        {
            //disables nonessential buttons for operation

            SaveButton.Visible = false;
            deleteButton.Visible = false;
            CancelButton.Visible = true;
            DeleteEventButton.Enabled = false;
            EditEventButton.Enabled = true;
            ViewEventButton.Enabled = false;
            ViewMonthlyButton.Enabled = false;
            CancelButton.Visible = true;
            AddEventButton.Enabled = false;
            EditEventButton.BackColor = Color.Red;
            panel1.Visible = true;
            StartingTimeTextBox.Text = "";
            StartingTimeTextBox.Visible = false;
            comboBox1.Visible = true;
            TitleTextBox.Text = "";
            EndingTimeTextBox.Text = "";
            EndingTimeTextBox.Visible = false;
            comboBox2.Visible = true;
            ReminderTimeTextBox.Text = "";
            LocationTextBox.Text = "";
            AttendeesTextBox.Text = "";
            DescriptionTextBox.Text = "";

            updateButton.Visible = true;


            
        }

        private void ViewEventButton_Click(object sender, EventArgs e)
        {
            //allows the user to only view an event
            SaveButton.Visible = false;
            deleteButton.Visible = false;
            updateButton.Visible = false;
            CancelButton.Visible = true; 
            DeleteEventButton.Enabled = false;
            EditEventButton.Enabled = false;
            ViewEventButton.Enabled = true;
            ViewMonthlyButton.Enabled = false;
            
            AddEventButton.Enabled = false;
            ViewEventButton.BackColor = Color.Red;
            panel1.Visible = true;
            StartingTimeTextBox.Text = "";
            StartingTimeTextBox.Visible = false;
            comboBox1.Visible = true;
            TitleTextBox.Text = "";
            EndingTimeTextBox.Text = "";
            EndingTimeTextBox.Visible = false;
            comboBox2.Visible = true;
            ReminderTimeTextBox.Text = "";
            LocationTextBox.Text = "";
            AttendeesTextBox.Text = "";
            DescriptionTextBox.Text = "";
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            //checks if the user wants to delete the event, then deletes it

            String message;
            String caption;
            MessageBoxButtons buttons;
            if (selectedEvent == null)
            {
                message = "There is no event selected.";
                caption = "";
                buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, buttons);
            }
            else
            {
                message = "do you really want to delete the event?";
                caption = "Delete event";
                buttons = MessageBoxButtons.YesNo;

                DialogResult result;

                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    String thisDate = monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd");
                    selectedEvent.deleteSelectedEvent();
                    label1.Text = "Events on " + thisDate;
                    eList = Event.getEventList(thisDate);
                    listBox1.Items.Clear();
                    for (int i = 0; i < eList.Count; i++)
                    {
                        Event currentEvent = (Event)eList[i];
                    }
                    emptyEventForm();
                    panel1.Visible = false;
                    message = "The event was deleted";
                    caption = "Delete event";
                    buttons = MessageBoxButtons.OK;
                    MessageBox.Show(message, caption, buttons);
                    AddEventButton.Enabled = true;
                    DeleteEventButton.Enabled = true;
                    DeleteEventButton.BackColor = SystemColors.ButtonFace;
                    EditEventButton.Enabled = true;
                    ViewEventButton.Enabled = true;
                    ViewMonthlyButton.Enabled = true;
                }



            }

        }

        private void ViewMonthlyButton_Click(object sender, EventArgs e)
        {
            // gets all events occuring throughout the month and puts it into the list
            AddEventButton.Enabled = false;
            DeleteEventButton.Enabled = false;
            EditEventButton.Enabled = false;
            ViewEventButton.Enabled = false;
            ViewMonthlyButton.BackColor = Color.Red;
            String thisDate = monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd");
            eList = Event.getMonthly(thisDate);
            panel1.Visible = true;
            listBox1.Items.Clear();
            emptyEventForm();
            CancelButton.Visible = true;
            for (int i = 0; i < eList.Count; i++)
            {
                Event currentEvent = (Event)eList[i];
                String aString = currentEvent.getStartTime() + " " + currentEvent.getTitle();
                listBox1.Items.Add(aString);
            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            //update all data
            
            Event newEvent = new Event();
            newEvent.updateEventValue(TitleTextBox.Text, StartingTimeTextBox.Text, EndingTimeTextBox.Text, ReminderTimeTextBox.Text, LocationTextBox.Text, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"), DescriptionTextBox.Text);
            eList.Remove(selectedEvent);
            if(newEvent.checkConflict(eList)==false)
            {
                String message = "The new event has time conflicts with some existing event.";
                String caption = "Error Detected in Time Specification";
                MessageBoxButtons button = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, button);
                eList.Add(selectedEvent);
            }
            else
            {
                selectedEvent.update(newEvent);


                String message = "The event was updated.";
                String caption = "Edit Event";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, buttons);
                AddEventButton.Enabled = true;
                DeleteEventButton.Enabled = true;
                EditEventButton.BackColor = SystemColors.ButtonFace;
                EditEventButton.Enabled = true;
                ViewEventButton.Enabled = true;
                ViewMonthlyButton.Enabled = true;
                emptyEventForm();
                panel1.Visible = false;
            }
           /* selectedEvent.update(newEvent);
  

            String message = "The event was updated.";
            String caption = "Edit Event";
            MessageBoxButtons buttons = MessageBoxButtons.OK;
            MessageBox.Show(message, caption, buttons);
            AddEventButton.Enabled = true;
            DeleteEventButton.Enabled = true;
            EditEventButton.BackColor = SystemColors.ButtonFace;
            EditEventButton.Enabled = true;
            ViewEventButton.Enabled = true;
            ViewMonthlyButton.Enabled = true;
            emptyEventForm();
            panel1.Visible = false;
            */
        }
    }
}
